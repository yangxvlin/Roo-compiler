module PrettyJoey (pp)
where
import JoeyAST

--  Pretty print a whole program:

pp :: Program -> String
pp _
  = "Very pretty!"

